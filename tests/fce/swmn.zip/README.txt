----------------------------- Snowman - NFS4 ADDON -----------------------------

Folder Name:      swmn
Editors:      Benny
Base:      model made from scratch, original textures
Additional Info:      features original performance, full Fedata support
        MERRY CHRISTMAS AND A HAPPY NEW YEAR'S EVE
Known issues:      it's possible to drive on summer tracks
Software Used:      FCE Center, Zanoza Modeler 1.05b, NFS Wizard v0.5.0.79
Installation:      drop the car.viv into data/cars/swmn
        and be sure there is no
        serialnumber conflict

2001/12

License:      CC BY-NC-SA 4.0
        <https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode>

This README.TXT may not be removed or altered from any source distribution.

-------------------------------------- EOF -------------------------------------